const neuralNetworkModule = (() => {
    function matrixMultiply(matrix1, matrix2, round = true, clamp = 255) {
        try {
            if (matrix1[0].length !== matrix2.length) {
                throw `Invalid multiplied matrix size; matrix1 length = ${matrix1[0].length}, matrix2 height = ${matrix2.length}`;
            }
        }
        catch(err) {
            throw err;
        }

        const product = [];
        const rows = matrix1.length;
        const columns = matrix2[0].length;
        for(let i = 0; i < rows; i++) {
            product.push(new Array(columns));
            for(let j = 0; j < columns; j++) {
                let currProduct = multiplyIthRowAndJthColumn(matrix1, matrix2, i, j);
                if (round) currProduct = Math.round(currProduct);
                if (clamp && (currProduct > clamp || currProduct < -clamp)) currProduct = clamp;
                product[i][j] = currProduct; 
            }
        }

        return product;
    }

    function multiplyIthRowAndJthColumn(matrix1, matrix2, i, j) {
        let sum = 0;
        for(let index = 0; index < matrix1[i].length; index++) {
            sum += matrix1[i][index] * matrix2[index][j];
        }
        return sum;
    }

    function calcResult(input, weights) {
        let activeLayerValues = input;
        weights.forEach(weightMatrix => {
            activeLayerValues = matrixMultiply(activeLayerValues, weightMatrix);
        })
        return activeLayerValues;
    }

    return {
        matrixMultiply,
        calcResult,
    }
})();

// переписать на 16х16 изображения
const pixelsInSubImage = 256 * 256;
const valuesInAPixel = 3;
const defaultWeightValue = 1;
let learningParams = {};

const canvas = document.getElementById("image-container");
const ctx = canvas.getContext("2d");
const imageInput = document.getElementById("image-input");
imageInput.addEventListener("change", function() {
    const reader = new FileReader();
    reader.addEventListener("load", () => {
        const uploadedImage = new Image();
        uploadedImage.addEventListener("load", () => {
            ctx.drawImage(uploadedImage, 0, 0);
            ctx.createImageData(256, 256);
        });
        uploadedImage.src = reader.result;
    });
    reader.readAsDataURL(this.files[0]);
});

function createNewNeuralNetworkInput() {
    const neuralNetworkInput = [];
    for(let i = 0; i < 256; i++) {
        for(let j = 0; j < 256; j++) {
            const currPixelData = ctx.getImageData(i, j, 1, 1).data;
            neuralNetworkInput.push(colorValueMapper(currPixelData[0]));
            neuralNetworkInput.push(colorValueMapper(currPixelData[1]));
            neuralNetworkInput.push(colorValueMapper(currPixelData[2]));
        }
    }
    return [neuralNetworkInput];
}

function colorValueMapper(value) {
    return (2 * value / 255) - 1;
}

const compressedImageCanvas = document.getElementById('compressed-image-container');
const compressedImageCtx = compressedImageCanvas.getContext("2d");

document.getElementById('compress-button').addEventListener('click', () => {
    const neuronsOnSecondLayer = +prompt('Neurons on the second layer:');
    if (!neuronsOnSecondLayer || isNaN(neuronsOnSecondLayer) || neuronsOnSecondLayer % 1 !== 0) return;
    const learningCoefficient = +prompt('Learning coefficient:');
    if (!learningCoefficient || isNaN(learningCoefficient) || learningCoefficient < 0 || learningCoefficient > 0.01) return;

    try {
        const input = createNewNeuralNetworkInput();
        const weights = setRandomWeights(neuronsOnSecondLayer);
        const secondLayerValues = neuralNetworkModule.matrixMultiply(input, weights[0]);
        const compressionResult = neuralNetworkModule.matrixMultiply(secondLayerValues, weights[1]);
        const diff = subtractMatrices(compressionResult, input);
        learningParams = {
            weights: weights.map(matrixToArray),
            learningCoefficient,
            inputTransposed: matrixToArray(transposeMatrix(input)),
            secondLayerValuesTransposed: matrixToArray(transposeMatrix(secondLayerValues)),
            diff: matrixToArray(diff)
        }

        const compressedImageData = compressedImageCtx.createImageData(256, 256);
        for (
            let currResultColorValueIndex = 0, imageDataIndex = 0;
            currResultColorValueIndex < compressionResult[0].length;
            currResultColorValueIndex += 3, imageDataIndex += 4
        ) {
            compressedImageData.data[imageDataIndex] = compressionResult[0][currResultColorValueIndex];
            compressedImageData.data[imageDataIndex + 1] = compressionResult[0][currResultColorValueIndex + 1];
            compressedImageData.data[imageDataIndex + 2] = compressionResult[0][currResultColorValueIndex + 2];
            compressedImageData.data[imageDataIndex + 3] = 255;
        }
        compressedImageCtx.putImageData(compressedImageData, 0, 0);
    }
    catch(err) {
        console.error(err);
        return;
    }
});

document.getElementById('next-learning-step-button').addEventListener('click', () => {
    tuneWeights(learningParams);
});

function setRandomWeights(neuronsOnSecondLayer) {
    const firstWeights = [];
    for(let i = 0; i < pixelsInImage * valuesInAPixel; i++) {
        const newRow = [];
        for(let j = 0; j < neuronsOnSecondLayer; j++) {
            newRow.push(Math.random() * (Math.random() > 0.5 ? 1 : -1));
        }
        firstWeights.push(newRow);
    }
    const secondWeights = transposeMatrix(firstWeights);
    return [firstWeights, secondWeights];
}


function transposeMatrix(matrix) {
    const transposed = [];
    for(let j = 0; j < matrix[0].length; j++) {
        transposed.push(new Array(matrix.length));
        for(let i = 0; i < matrix.length; i++) {
            transposed[j][i] = matrix[i][j];
        }
    }
    return transposed;
}

function subtractMatrices(matrix1, matrix2) {
    const result = [];
    const height = matrix1.length;
    const width = matrix1[0].length;
    for (let i = 0; i < height; i++) {
        result.push(new Array(width));
        for(let j = 0; j < width; j++) {
            result[i][j] = matrix1[i][j] - matrix2[i][j];
        }
    }
    return result;
}

function tuneWeights(params) {
    if (!params || !params.weights || !params.learningCoefficient || !params.inputTransposed || !params.secondLayerValuesTransposed || !params.diff) return;
    for(let key in params) {
        if(key === 'weights') {
            params[key] = params[key].map(arrayToMatrix);
        }
        else params[key] = arrayToMatrix(params[key]);
    }
    console.log(params);
    tuneSecondWeights(params.weights, params.learningCoef, params.secondLayerValuesTransposed, params.diff);
    tuneFirstWeights(params.weights, params.learningCoefficient, params.inputTransposed, params.diff);
    delete params;
}

function tuneFirstWeights(weights, learningCoef, inputTransposed, diff) {
    const a = neuralNetworkModule.matrixMultiply(inputTransposed, diff);
    delete inputTransposed;
    delete diff;
    const b = neuralNetworkModule.matrixMultiply(a, transposeMatrix(weights[1]));
    delete a;
    multiplyMatrixByNumber(b, learningCoef);

    weights[0] = subtractMatrices(weights[0], b)
}

function tuneSecondWeights(weights, learningCoef, secondLayerValuesTransposed, diff) {
    const a = neuralNetworkModule.matrixMultiply(secondLayerValuesTransposed, diff);
    delete secondLayerValuesTransposed;
    multiplyMatrixByNumber(a, learningCoef);

    weights[1] = subtractMatrices(weights[1], a);
}

function multiplyMatrixByNumber(matrix, number) {
    for (let i = 0; i < matrix.length; i++) {
        for (let j = 0; j < matrix[0].length; j++) {
            matrix[i][j] *= number;
        }
    }
}

function matrixToArray(matrix) {
    const result = [];
    for(let i = 0; i < matrix.length; i++) {
        for(let j = 0; j < matrix[0].length; j++) {
            result.push(matrix[i][j]);
        }
        result.push('this is a delimiter');
    }
    return result;
}

function arrayToMatrix(array) {
    if(!(array instanceof Array)) return array;
    const matrix = [];
    const height = array.filter(el => el === 'this is a delimiter').length;
    const width = array.findIndex(el => el === 'this is a delimiter');
    array = array.filter(el => el !== 'this is a delimiter');
    for(let i = 0; i < height; i++) {
        matrix.push(new Array(width));
        for(let j = 0; j < width; j++) {
            matrix[i][j] = array[width * i + j];
        }
    }
    return matrix;
}